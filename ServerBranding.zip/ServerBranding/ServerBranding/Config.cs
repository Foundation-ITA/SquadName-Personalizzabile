﻿using Exiled.API.Interfaces;

namespace ServerBranding
{
    public class Config : IConfig
    {
        public bool IsEnabled { get; set; } = true;
    }
}
